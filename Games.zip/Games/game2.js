const resultText = document.getElementById('result-text');
const choices = ['rock', 'paper', 'scissors'];
let playerScore = 0;
let computerScore = 0;
const maxScore = 3; // Change this value to the desired maximum score

function playRound(playerChoice) {
    const computerChoice = choices[Math.floor(Math.random() * 3)];

    if (playerChoice === computerChoice) {
        resultText.textContent = `It's a draw! Both chose ${playerChoice}.`;
    } else if (
        (playerChoice === 'rock' && computerChoice === 'scissors') ||
        (playerChoice === 'paper' && computerChoice === 'rock') ||
        (playerChoice === 'scissors' && computerChoice === 'paper')
    ) {
        resultText.textContent = `You win! ${playerChoice} beats ${computerChoice}.`;
        playerScore++;
    } else {
        resultText.textContent = `You lose! ${computerChoice} beats ${playerChoice}.`;
        computerScore++;
    }

    // Update scores
    updateScores();

    // Check for a winner
    checkForWinner();
}

function updateScores() {
    document.getElementById('player-score').innerText = `Player: ${playerScore}`;
    document.getElementById('computer-score').innerText = `Computer: ${computerScore}`;
}

function checkForWinner() {
    if (playerScore === maxScore) {
        displayResult("Player wins the game!");
        resetGame();
    } else if (computerScore === maxScore) {
        displayResult("Computer wins the game!");
        resetGame();
    }
}

function resetGame() {
    // Reset scores
    playerScore = 0;
    computerScore = 0;
    updateScores();
}

// ... additional functions and code as needed ...

